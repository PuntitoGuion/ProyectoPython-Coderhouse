from setuptools import setup

setup(
    name = "paquete_coder",
    version = "1.0",
    description = "Paquete de primer y segunda pre-entrega",
    author = "Julián Ferrari",
    author_email = "julianferrari78@gmail.com",

    packages = ["paquete_coder"]
)